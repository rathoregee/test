# sync router func

# !!! PLEASE EDIT THE BELOW !!!

Routes change entities to destination domains

## Author

kamran

### Next steps

Please complete the below sections.Think about adding testing details etc.

## Environment variables

Describe the environment variables required.

## API Gateway Configuration

Describe the API Gateway configuration if required

## Service Dependencies

List the service dependancies

