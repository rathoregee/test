import { Injectable } from '@angular/core'
import { Subject, Observable } from 'rxjs'
import { IEvent } from './event.model'

@Injectable()
export class EventService {
  getEvents():Observable<IEvent[]> {
    let subject = new Subject<IEvent[]>()
    setTimeout(() => {subject.next(EVENTS); subject.complete(); }, 100)
    return subject
  }

  getEvent(id:number):IEvent {
    return EVENTS.find(event => event.id === id)
  }

  saveEvent(event) {
    event.id = 999
    event.session = []
    EVENTS.push(event)
  }

  updateEvent(event) {
    let index = EVENTS.findIndex(x => x.id = event.id)
    EVENTS[index] = event
  }
}

const EVENTS:IEvent[] = [
    {
      id: 1,
      name: '1',
      date: new Date('9/26/2036'),
      time: '10:00 am',
      price: 599.99,
      imageUrl: '/assets/images/angularconnect-shield.png',
      location: {
        address: '1057 DT',
        city: 'London',
        country: 'England'
      },
      sessions: [
        {
          id: 1,
          name: "Using Angular 4 Pipes",
          presenter: "Peter Bacon Darwin",
          duration: 1,
          level: "Intermediate",
          abstract: `Learn all about the new pipes in Angular 4, both
          how to write them, and how to get the new AI CLI to write
          them for you. Given by the famous PBD, president of Angular
          University (formerly Oxford University)`,
          voters: ['bradgreen', 'igorminar', 'martinfowler']
        }
      ]
    }
  ]