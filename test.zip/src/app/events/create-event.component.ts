import { Component } from '@angular/core'
import { Router } from '@angular/router'
import { EventService } from './shared/index'
import { FormControl, FormGroup, Validators } from '@angular/forms'

@Component({
  templateUrl: './create-event.component.html',
  styles: [`
    em {float:right; color:#E05C65; padding-left:10px;}
    .error input {background-color:#E3C3C5;}
    .error ::-webkit-input-placeholder { color: #999; }
    .error :-moz-placeholder { color: #999; }
    .error ::-moz-placeholder {color: #999; }
    .error :ms-input-placeholder { color: #999; }
  `]
})
export class CreateEventComponent {
  isDirty = false
  eventForm: FormGroup
  limit: FormControl
  rent: FormControl
  type: FormControl

  constructor(private router: Router, private eventService: EventService) {  }

  ngOnInit() {
    this.limit = new FormControl('', Validators.required)
    this.rent = new FormControl('', Validators.required)
    this.type = new FormControl('', Validators.required)
  }
  saveEvent(inp: any) {
    debugger
    this.eventService.saveEvent({ id: inp.limit, name: inp.rent, imageUrl: inp.type });

    this.router.navigate(['/events'])
  }

  cancel() {
    this.router.navigate(['/events'])
  }
}